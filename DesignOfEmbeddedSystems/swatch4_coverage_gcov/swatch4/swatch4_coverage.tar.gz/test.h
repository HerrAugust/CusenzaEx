int test_timesetmode();

int test_add_minutes();

int init_suite_SWatch2018();