/*
 * lcd_add.h
 *
 *  Created on: 24/ott/2015
 *      Author: admim
 */

#ifndef LCD_ADD_H_
#define LCD_ADD_H_

void LCD_DrawStringNB(unsigned short int x, unsigned short int y, char *str);

#endif /* LCD_ADD_H_ */
