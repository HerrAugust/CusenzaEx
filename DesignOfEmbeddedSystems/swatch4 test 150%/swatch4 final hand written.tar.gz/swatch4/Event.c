/*
 * Event.c
 *
 *  Created on: 22/ott/2015
 *      Author: admim
 */

#include "Event.h"

Events evts;
