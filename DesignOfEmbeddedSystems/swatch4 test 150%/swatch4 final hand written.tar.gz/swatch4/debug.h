/*
 * debug.h
 *
 *  Created on: 25/ott/2015
 *      Author: admim
 */

#ifndef DEBUG_H_
#define DEBUG_H_

void debuginfo(unsigned int id, int a, int b, int c);

#endif /* DEBUG_H_ */
